package com.tacos;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class TacoShopApplication {

	public static void main(String[] args) {
		SpringApplication.run(TacoShopApplication.class, args);
	}

}
